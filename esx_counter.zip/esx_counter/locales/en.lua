Locales ['en'] = {
	['server']   = '~g~ON~w~LI~r~NE',
}

