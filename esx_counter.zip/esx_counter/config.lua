Config        = {}
Config.Locale = 'en'

Config.Color = ''
Config.MaxPlayers = '64'

-- Yellow
-- Red
-- Green
-- Purple
-- Blue
-- Orange
-- White